Page\: `[Gear Icon] -> Dependencies`

The dependency page allows viewing of dependency information and the ability to initiate their installation.
