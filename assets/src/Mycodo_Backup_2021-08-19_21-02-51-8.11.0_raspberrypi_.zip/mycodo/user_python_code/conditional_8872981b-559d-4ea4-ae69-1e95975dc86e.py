import os
import sys
sys.path.append(os.path.abspath('/var/mycodo-root'))
from mycodo.controllers.base_conditional import AbstractConditional
from mycodo.mycodo_client import DaemonControl
control = DaemonControl(pyro_timeout=30.0)

class ConditionalRun(AbstractConditional):
    def __init__(self, logger, function_id, message):
        super(ConditionalRun, self).__init__(logger, function_id, message, timeout=30.0)

        self.logger = logger
        self.function_id = function_id
        self.variables = {}
        self.message = message
        self.running = True

    def conditional_code_run(self):
        waterTemp = self.condition("4c81a98d-f67c-4c11-921c-86af320559ca")
        wetBulbTemp = self.condition("e98e2e53-be6e-490a-83e4-0e96e186e97b")

        if wetBulbTemp > waterTemp:
            self.message += "Humidity controller error."
            self.run_action("1e4a7fb6-3db1-4464-b1ab-6182e1f02a8e", message=self.message)
            self.run_action("137f2ae4-4b5c-4671-b1e2-fc28d917ef86")
            self.logger.error(f"Humidity controller error. Shutting off control. (water={waterTemp}; wet bulb={wetBulbTemp}")
