"""base Mycodo version 7.0.0

Revision ID: 90wvmtnznxb8
Revises:
Create Date: 2018-10-21 13:11:10.235402

"""

# revision identifiers, used by Alembic.
revision = '90wvmtnznxb8'
down_revision = None
branch_labels = None
depends_on = None


def upgrade():
    pass


def downgrade():
    pass


